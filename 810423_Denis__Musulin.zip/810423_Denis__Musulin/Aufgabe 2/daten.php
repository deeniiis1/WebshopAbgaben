<?php
if ($_GET["auswahl"] == "wi") {

    $Module = array ("Grundlagen dert Wirtschaftsinformatik", 
                     "Grundlagen der Wirtschaftswissenschaften", 
                     "Grundlagen der Informatik", 
                     "Mathematische Grundlagen");

    echo ausgabe($Module);
} elseif ($_GET["auswahl"] == "mki") {

    $Module = array ("Theroretische Grundlagenm 1 Vorlesung", 
                     "Theroretische Grundlagen 1 Praktikum", 
                     "Informatik 1 Vorlesung", 
                     "Informatik Vorlesung 1 Praktikum", 
                     "Grafik", 
                     "Fotografie");

    echo ausgabe($Module);
} elseif ($_GET["auswahl"] == "meti") {

    $Module = array ("Formale Methode 1 Vorlesung", 
                     "Formale Methoden 1 Praktikum", 
                     "Informatik 1 Vorlesung", 
                     "Informatik 1 Praktikum", 
                     "Medizininfinformatik", 
                     "Medizinische Grundlagen");
    echo ausgabe($Module);
} else {

    echo ("Keine Module gefunden");
}

function ausgabe($moduleZumAusgeben)
{
    $AusgabenListe = "<ul>";

        foreach ($moduleZumAusgeben as $modul) {
            $AusgabenListe .= "<li>$modul</li>";
        }

    $AusgabenListe .= "</ul>";
    return $AusgabenListe;
}
?>