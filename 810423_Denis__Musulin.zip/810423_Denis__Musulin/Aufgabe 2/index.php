<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aufgabe 2</title>
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script type="text/javascript">
        $(function (){
            $('#Studienart').change(function(){
                if($(this).val()!= ""){
                    $.get("daten.php",
                    { auswahl: $(this).val()},
                    function(daten){
                        $('#ausgabe').html(daten);
                    });
                }
            });
        });
    </script>
</head>
<body>
    <form>
        <p>
            <label for="Studienart">Studienart</label>
            <select name="Studienart" id="Studienart" onchange="moduleAbrufen()">
                <option value="">wählen</option>
                <option value="wi">Wirtschaftsinformatik</option>
                <option value="mki">Medien- und Kommunikationinformatik</option>
                <option value="meti">Medizin-Technische Informatik</option>
            </select>
        </p>
    </form>
    <div id="ausgabe"></div>
</body>
</html>