<?php
    if(isset($_GET["auswahl"])){
        echo "<b>Antwort vom Server: ".$_GET["auswahl"]."</b>";
        echo "<div><ul><li>Wirtschaft</li><li>Informatik</li><li>Medizin</li></ul></div>";
        echo "<img src='roboter.jpeg' alt='Robo' title='WI-Turbo'/>";
    }
?>