<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Aufgabe 3</title>
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script type="text/javascript">
            $(document).ready(function() {
                setInterval(function() {
                    $.get("daten.php",
                    { auswahl:1*new Date()},
                        function(daten) {
                            $("#ausgabe").html(daten);
                        });
                },1000);
            });
    </script>
</head>
<body>
    <h1>Herzlich Willkommen!</h1>
    <div id="ausgabe"></div>
</body>
</html>