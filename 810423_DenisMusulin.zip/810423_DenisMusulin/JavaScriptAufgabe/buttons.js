function enterValue(){
    let EnteredValue = document.getElementById("input").value;
    EnteredValue = parseInt(EnteredValue) 
    alert("Input Value: " + EnteredValue)
    createButtons(EnteredValue)
}
function createButtons(numberOfButtons) {
    const buttonContainer = document.getElementById('buttoncontainer');
  
    for (let i = 1; i <= numberOfButtons; i++) {
      const button = document.createElement('button');
      button.textContent = `Button ${i}`;
      button.addEventListener('click', function() {
        alert(`Hello Button Number: ${i}`);
      });
      buttonContainer.appendChild(button);
      const lineBreak = document.createElement('br');
      buttonContainer.appendChild(lineBreak);
    }
  }
